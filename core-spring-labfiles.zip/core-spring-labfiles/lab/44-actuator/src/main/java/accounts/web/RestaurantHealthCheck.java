package accounts.web;

/**
 * TODO-17a: Make this class implement HealthIndicator
 *  - Make this class a component
 *  - Add a constructor to pass in the restaurant repository
 *    and use it to implement health().
 *  - health() should return DOWN if the repository is empty
 *    (no restaurants) or UP otherwise.
 *
 * TODO-24 (Extra credit): Experiment with HealthIndicator (Read lab document)
 */
public class RestaurantHealthCheck {

}
